This is a simple pyduq test case which can either be run from a command line or from Jupyter Notebook.

To use:

Run validate.bat

This will connect to an open government website, download a sample CSV file, and then run pyduq to generate a metadata JSON file and perform a validation & data profile.
