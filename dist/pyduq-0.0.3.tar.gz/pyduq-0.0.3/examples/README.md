# pyduq Examples

The following folders contain examples of using pyduq to validate opendata.
Each set includes a dataset (CSV file), a metadata file (JSON) and a BAT file
to run to perform the data quality validation.

Feel free to experiment with these. Run: python pyduqmain --help to see 
the command line options available.

Shane


